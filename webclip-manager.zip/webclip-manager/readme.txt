Here's all you need to do:

1) Download and unzip the zip file.

2) You'll have a directory/folder called webclip-manager, put this into 
your plugin directory.

3) Go to your admin panel and activate the plugin.

4) Now go to Options -> Webclip Mgr

5) Enter the location of your Webclip image.  It may be in 
any of several formats: ico, gif, or jpg.  There's no restriction on its 
name or location, other than that it's a valid and reachable URI.
You can always come back here and change this whenever you wish.
Changing your theme or upgrading WP will not affect this.

The big issue is that you want an image at least 47x47 pixels. The bigger (and square) the better for this one since it will resize and automatically overlay the highlight when it's saved.

A later version will have upload tools in the plugin settings page so you can upload the image all in one place.

Question, comments, complaints feedback?:  http://cdcstudios.com/wordpress-plugins/iphone-webclip-manager/